package com.Ben.mygame;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class MyHandler extends Handler
{
    private MyAnimation ma;

    public MyHandler(MyAnimation ma)
    {
        super();
        this.ma = ma;
    }

    public void handleMessage(Message msg)
    {
        super.handleMessage(msg);
        Bundle data = msg.getData();
        int num = data.getInt("count");
        ma.drawDmut(num);
    }
}
