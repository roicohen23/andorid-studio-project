package com.Ben.mygame;

import android.os.Bundle;
import android.os.Message;

public class MyThread extends Thread
{
    private boolean stop;
    private MyHandler mh;

    public MyThread(MyHandler _mh)
    {
        this.mh = _mh;
    }

    public void run()
    {
        stop = false;
        int i = 0;
        while(!stop)
        {
            i++;
            if(i == 13)
                i = 1;

            sendCounterToActive(i);

            try
            {
                this.sleep(50);
            }

            catch(InterruptedException e1)
            {
                e1.printStackTrace();
            }
        }
    }

    private void sendCounterToActive (int num)
    {
        Message msg = new Message();
        Bundle data = msg.getData();
        data.putInt("count", num);
        mh.handleMessage(msg);
    }

    public void setStop(boolean a)
    {
        stop = a;
    }
}
