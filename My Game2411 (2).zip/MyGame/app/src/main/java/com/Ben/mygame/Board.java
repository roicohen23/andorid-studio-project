package com.Ben.mygame;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Board {
    public static final int MisparShurot = 8;
    public static final int MisparAmudot = 8;
    private int boardMatrix[][];
    public static final String Filename = "data.txt";
    int currentPlayer;
    private MyAnimation anim;

    public Board() {
        this.boardMatrix = new int[MisparShurot][MisparAmudot];
        buildBoard();
        // initBoard();
    }

    public void buildBoard() {

        for (int i = 0; i < 3; i++) {
            if (i % 2 == 0) {
                for (int k = 0; k < Board.MisparAmudot; k++) {
                    if (k % 2 == 0) {
                        boardMatrix[i][k] = 2;
                    } else {
                        boardMatrix[i][k] = 1;
                    }
                }
            } else if (i % 2 != 0) {
                for (int k = 0; k < Board.MisparAmudot; k++) {
                    if (k % 2 != 0) {
                        boardMatrix[i][k] = 2;
                    } else {
                        boardMatrix[i][k] = 1;
                    }
                }

            }
        }


        for (int j = 5; j < Board.MisparShurot; j++) {
            if (j % 2 == 0) {
                for (int k = 0; k < Board.MisparAmudot; k++) {
                    if (k % 2 == 0) {
                        boardMatrix[j][k] = 2;
                    } else {
                        boardMatrix[j][k] = -1;
                    }
                }
            } else if (j % 2 != 0) {
                for (int k = 0; k < Board.MisparAmudot; k++) {
                    if (k % 2 != 0) {
                        boardMatrix[j][k] = 2;
                    } else {
                        boardMatrix[j][k] = -1;
                    }
                }
            }
        }

        for (int j = 3; j < 5; j++) {
            for (int k = 0; k < Board.MisparAmudot; k++) {
                if (j == 3) {
                    if (k % 2 != 0) {
                        boardMatrix[j][k] = 2;
                    } else {
                        boardMatrix[j][k] = 0;
                    }
                } else {
                    if (k % 2 == 0) {
                        boardMatrix[j][k] = 2;
                    } else {
                        boardMatrix[j][k] = 0;
                    }
                }

            }


        }
    }

    public boolean isOkForTheKing(int rowFrom,int rowTo , int colFrom, int colTo, int num, int currentPlayer)
    {
        int row = rowFrom;
        int col = colFrom;
        int cnt = 0;
        boolean ok = false;
        for (int i = 0; i < num; i++)
        {
            if(boardMatrix[rowTo][colTo] == boardMatrix[row][col] && cnt < 2 )
                ok = true;
            if (boardMatrix[row][col] == currentPlayer* -1)
                cnt++;
            if (colTo > colFrom)
            {
                col = col + 1;
                if (currentPlayer == -1)
                    row = row + 1;
                else
                    row = row - 1;
            }
            else
            {
                col = col - 1;
                if (currentPlayer == 1)
                    row = row + 1;
                else
                    row = row - 1;

            }



        }


        return false;
    }
    public int cmout(int rowFrom , int rowTo , int currentPlayer) {
        int num = 0;
        if (currentPlayer == 3) {
            num = rowTo - rowFrom;
        }
        if (currentPlayer == -3) {
            num = rowFrom - rowTo;
        }
        return num;
    }
    public int getValue(int row, int col) {
        return boardMatrix[row][col];
    }

    public boolean isStreigth(int rowFrom, int colFrom, int rowTo, int colTo, int currentPlayer)
    {
        int row = rowFrom;
        int col = colFrom;
            if(colFrom > colTo)
            {
                if((rowFrom - rowTo) != (colFrom - colTo))
                    return false;
            }
            if(colFrom < colTo)
            {
                while(col < colTo)
                {
                    if((rowFrom - rowTo) != (colTo - colFrom))
                        return false;
                }

            }
        return true;
    }

    public boolean isLegalKing(int rowFrom, int colFrom, int rowTo, int colTo, int currentPlayer)
    {
        int row = rowFrom;
        int col = colFrom;
        if(boardMatrix[rowTo][colTo] == 2)
            return false;
        if (boardMatrix[rowFrom][colFrom] != currentPlayer * 3)
            return false;
        if (boardMatrix[rowTo][colTo] == currentPlayer * -1 || boardMatrix[rowTo][colTo] == currentPlayer * -3)
        {

            if (rowTo > rowFrom)
            {
                if (colTo > colFrom)
                {
                    if (rowTo == 7)
                        return false;
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo + 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }
                }
                else
                {
                    if (rowTo == 7)
                        return false;
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo + 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }

                }
            }
            else
            {
                if (colTo > colFrom)
                {
                    if (rowTo == 0)
                        return false;
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo + 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }
                }
                else
                {
                    if (rowTo == 0)
                        return false;
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo + 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }
                }
            }

        }
       if(rowFrom > rowTo)
       {
           if(colFrom > colTo)
           {
               if(Math.abs(colFrom - colTo) != Math.abs(rowFrom - rowTo))
                   return false;
           }
           else
           {
               if((colTo - colFrom) != (rowFrom - rowTo))
                   return false;
           }
       }
       else
       {
           if(colFrom > colTo)
           {
               if((colFrom - colTo) != (rowTo - rowFrom))
                   return false;
           }
           else
           {
               if((colTo - colFrom) != (rowTo - rowFrom))
                   return false;
           }
       }

       // if(boardMatrix[rowFrom][colFrom] != -3 || boardMatrix[rowFrom][colFrom] != 3)
         //  return false;



        return true;
    }
    public boolean isRule(int rowFrom, int colFrom, int rowTo, int colTo, int currentPlayer)
    {
        int row = rowFrom;
        int col = colFrom;
        int cnt = 0;
        if (Math.abs(rowFrom - rowTo) == 1)
            return true;
        while(col != colTo)
        {
            if (col > colTo)
            {
                if (rowFrom > rowTo)
                {

                }

            }
            else
            {

            }
        }
        return true;
    }
    public boolean isLegal(int rowFrom, int colFrom, int rowTo, int colTo, int currentPlayer) {
        if (boardMatrix[rowFrom][colFrom] != currentPlayer)
            return false;
        if (boardMatrix[rowTo][colTo] == 2)
            return false;

        if (currentPlayer == 1)
        {
            if (rowTo == 7)
            {
                boardMatrix[rowTo][colTo] = 3;
            }
        }
        if (currentPlayer == -1)
        {
            if (rowTo == 0)
            {
                boardMatrix[rowTo][colTo] = -3;
            }
        }

//
        if (currentPlayer == -1) { //WHITE
            if (!((rowTo == rowFrom - 1 && colTo == colFrom - 1) || (rowTo == rowFrom - 1 && colTo == colFrom + 1)))
                return false;
            if (boardMatrix[rowTo][colTo] == 1 || boardMatrix[rowTo][colTo] == 3) {
                if (rowTo == rowFrom + 1) {
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo + 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }
                    boardMatrix[rowFrom][colFrom] = 0;
                    if (rowTo == 0)
                        boardMatrix[rowTo][colTo] = currentPlayer * 3;
                    else
                        boardMatrix[rowTo][colTo] = currentPlayer;
                    return false;
                } else {
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo - 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }
                    boardMatrix[rowFrom][colFrom] = 0;
                    if (rowTo == 0)
                        boardMatrix[rowTo][colTo] = currentPlayer * 3;
                    else
                        boardMatrix[rowTo][colTo] = currentPlayer;
                    return false;
                }
            }
        }
        if (currentPlayer == 1) {
            if (!((rowTo == rowFrom + 1 && colTo == colFrom - 1) || (rowTo == rowFrom + 1 && colTo == colFrom + 1)))
                return false;
            if (boardMatrix[rowTo][colTo] == -1 || boardMatrix[rowTo][colTo] == -3) {
                if (rowTo == rowFrom + 1) {
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo + 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }
                    boardMatrix[rowFrom][colFrom] = 0;
                    if (rowTo == 7)
                        boardMatrix[rowTo][colTo] = currentPlayer * 3;
                    else
                        boardMatrix[rowTo][colTo] = currentPlayer;
                    return false;
                } else {
                    boardMatrix[rowTo][colTo] = 0;
                    rowTo = rowTo - 1;
                    if (colTo == colFrom - 1) {
                        colTo = colTo - 1;
                    }
                    if (colTo == colFrom + 1) {
                        colTo = colTo + 1;
                    }
                    boardMatrix[rowFrom][colFrom] = 0;
                    if (rowTo == 7)
                        boardMatrix[rowTo][colTo] = currentPlayer * 3;

                    else
                        boardMatrix[rowTo][colTo] = currentPlayer;
                    return false;
                }
            }
            if (boardMatrix[rowTo][colTo] != 0 && (boardMatrix[rowTo - 1][colTo - 1] != 0 || boardMatrix[rowTo - 1][colTo + 1] != 0))
                return false;
        }
        return true;

    }

    public int makeMove(int rowFrom, int colFrom, int rowTo, int colTo, int currentPlayer) {
        if (boardMatrix[rowFrom][colFrom] == -3 || boardMatrix[rowFrom][colFrom] == 3)
        {
            Log.d("makeMove()","in");
            if (isLegalKing(rowFrom, colFrom, rowTo, colTo, currentPlayer))
            {
                Log.d("makeMove()","xxxxxxx");
                boardMatrix[rowFrom][colFrom] = 0;
                boardMatrix[rowTo][colTo] = currentPlayer * 3;
                return 0;
            }
            else
                return 1;

        }
        if (boardMatrix[rowFrom][colFrom] == -1 || boardMatrix[rowFrom][colFrom] == 1)
        {
            if (isLegal(rowFrom, colFrom, rowTo, colTo, currentPlayer)) {
                boardMatrix[rowFrom][colFrom] = 0;
                boardMatrix[rowTo][colTo] = currentPlayer;
                if(isKing(rowTo))
                {
                    if (currentPlayer == -1)
                        boardMatrix[rowTo][colTo] = -3;
                    else
                        boardMatrix[rowTo][colTo] = 3;
                }
                return 0;
            }
            else
                return 1;
        }


     /*   if(isLegalKing( rowFrom,  colFrom,  rowTo,  colTo,  currentPlayer))
        {
            boardMatrix[rowFrom][colFrom] = 0;
            boardMatrix[rowTo][colTo] = currentPlayer * 3;
            return 0;
        }
        
      */

       return 1;
    }
    public boolean isKing(int rowTo)
    {
        if(rowTo == 0 || rowTo == 7)
            return true;
        return false;
    }

    public boolean winner(int currentPlayer) {

//        for (int i = 0; i < MisparShurot; i++) {
//            if ((boardMatrix[i][0] == currentPlayer && boardMatrix[i][1] ==  currentPlayer && boardMatrix[i][2] == currentPlayer) ||
//                    (boardMatrix[0][i] == currentPlayer && boardMatrix[1][i] ==  currentPlayer && boardMatrix[2][i] == currentPlayer))
//                return true;
//        }
//        if (boardMatrix[0][0] == currentPlayer && boardMatrix[1][1] == currentPlayer && boardMatrix[2][2] == currentPlayer) {
//            return true;
//        }
//        if (boardMatrix[0][2] == currentPlayer && boardMatrix[1][1] ==  currentPlayer && boardMatrix[2][0] == currentPlayer) {
//            return true;
//        }
        return false;
    }
    public boolean isWinner(int currentPlayer)
    {
        for (int i = 0; i < boardMatrix.length; i++)
        {
            for(int k = 0; k <boardMatrix[0].length; k++)
            {
                if(boardMatrix[i][k] == currentPlayer*-1)
                    return false;
            }
        }
        return true;
    }
    public void save(FileOutputStream fos, int currentPlayer) {
        // שמירת הלוח
        try {
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            BufferedWriter writer = new BufferedWriter(osw);

            writer.append(currentPlayer + ";");
            writer.append("\n");

            for (int i = 0; i < this.boardMatrix.length; i++) {
                for (int k = 0; k < this.boardMatrix[i].length; k++) {
                    if (this.boardMatrix[i][k] != 0) {
                        writer.append(i + ";" + k + ";" + this.boardMatrix[i][k]);
                        writer.append("\n");
                    }
                }
            }

            writer.close();
            osw.close();
            fos.close();
        } catch (Exception e) {

        }
    }


    public void load(FileInputStream fis) {
        // קריאת הלוח
        try {
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader reader = new BufferedReader(isr);
            for (int i = 0; i < this.boardMatrix.length; i++) {
                for (int k = 0; k < this.boardMatrix[i].length; k++)
                    this.boardMatrix[i][k] = 0;
            }

            String strLine = reader.readLine();

            String data[] = strLine.split(";");
            currentPlayer = Integer.parseInt(data[0]);
            strLine = reader.readLine();

            while (strLine != null) {
                data = strLine.split(";");
                int shura = Integer.parseInt(data[0]);
                int amuda = Integer.parseInt(data[1]);
                this.boardMatrix[shura][amuda] = Integer.parseInt(data[2]);
                strLine = reader.readLine();
            }

            reader.close();
            isr.close();
            fis.close();
        } catch (Exception e) {

        }
    }

    public int getCurrentPlayer() {
        return currentPlayer;
    }

    public void movePlayer() {
        int currentPlayer = 1;
        int camutLehitzot = 0;

        if (camutLehitzot > 2)
            currentPlayer = 2;

    }


}
