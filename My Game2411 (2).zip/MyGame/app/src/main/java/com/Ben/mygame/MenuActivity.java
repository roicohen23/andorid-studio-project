package com.Ben.mygame;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnStartGame, btnRules, btnsave;
    Dialog nameOfPlayers;
    EditText etFirstPlayer, etSecondPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        btnRules = findViewById(R.id.btnrules);
        btnRules.setOnClickListener(this);
        btnStartGame = findViewById(R.id.btnStart);
        btnStartGame.setOnClickListener(this);    }


    /**
     * the function create a dialog to give names to the players
     */
    public void playersNameDialog() {
        nameOfPlayers = new Dialog(this);
        nameOfPlayers.setContentView(R.layout.play_name_layout);
        nameOfPlayers.setTitle("Players Name");
        etFirstPlayer = (EditText) nameOfPlayers.findViewById(R.id.etFirst);
        etSecondPlayer = (EditText) nameOfPlayers.findViewById(R.id.etSecond);
        btnsave = (Button) nameOfPlayers.findViewById(R.id.btnPlay);
        btnsave.setOnClickListener(this);
        nameOfPlayers.setCancelable(true);
        nameOfPlayers.show();
        Toast.makeText(getApplicationContext(), "please put your names ", Toast.LENGTH_LONG).show();


    }

    @Override
    public void onClick(View v) {
        if (v == btnStartGame) {
            playersNameDialog();
        } else if (v == btnsave) {
            Intent in = new Intent(this, GameUiActivity.class);
            String first = etFirstPlayer.getText().toString();
            String second = etSecondPlayer.getText().toString();
            in.putExtra("Name1", first);
            in.putExtra("Name2", second);
            startActivity(in);
        } else if (v == btnRules) {
            Intent intent = new Intent(this, RulesActivity.class);
            startActivity(intent);
        }

    }

}