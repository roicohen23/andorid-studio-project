package com.Ben.mygame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RulesActivity extends AppCompatActivity implements View.OnClickListener {

    Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rules);
        back=(Button)findViewById(R.id.btnBack);
        back.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (back==v)
        {
            Intent intent=new Intent(this, MenuActivity.class);
            startActivity(intent);
        }
    }
}