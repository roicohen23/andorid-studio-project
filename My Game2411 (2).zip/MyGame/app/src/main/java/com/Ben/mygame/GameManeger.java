package com.Ben.mygame;

import android.content.Context;
import android.content.Intent;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class GameManeger {
    protected Board board;
    protected int currentPlayer;
    private GameUiInterface gameUI;
    MyHandler myHn;
    MyAnimation myAnim;

    public GameManeger(GameUiInterface _gameUI) {
        this.gameUI = _gameUI;
        this.board = new Board();
        this.currentPlayer = 1;
        gameUI.drawBoard(board);
        gameUI.markCurrentPlayer(currentPlayer);


    }
    public void isWinner(){
        if (board.isWinner(currentPlayer))
            gameUI.show_winner();
    }

    public int makeMove(int rowFrom, int colFrom, int rowTo, int colTo) {
        int p = board.makeMove(rowFrom, colFrom, rowTo, colTo, currentPlayer);
        gameUI.drawBoard(board);
        if (p == 0) {
            currentPlayer = currentPlayer * -1;
        }
        return currentPlayer;
    }

    public void restart() {
        board.buildBoard();
        currentPlayer = 1;
        gameUI.drawBoard(board);
        gameUI.markCurrentPlayer(currentPlayer);
    }

    public void loadBoard(FileInputStream fis) {
        //טעינת הלוח
        this.board.load(fis);
        currentPlayer = board.getCurrentPlayer();
        gameUI.markCurrentPlayer(currentPlayer);
        gameUI.drawBoard(board);
    }

    public void saveBoard(FileOutputStream fos) {
        this.board.save(fos, currentPlayer);
    }
}
