package com.Ben.mygame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class GameUiActivity extends AppCompatActivity implements View.OnClickListener, GameUiInterface {

    private GameManeger gameMgr;
    private Button caftor[][] = new Button[Board.MisparShurot][Board.MisparAmudot];
    String NameA, NameB, winnerName;
    private Button btnTor;
    int rowFrom = 0, colFrom = 0;
    boolean first_tap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_ui);

        Intent in = getIntent();
        if (in != null) {
            Bundle xtras = in.getExtras();
            NameA = xtras.getString("Name1");
            NameB = xtras.getString("Name2");
        }
        initButtons();
        gameMgr = new GameManeger(this);
        first_tap = true;
    }

    @Override
    public void show_winner() {
        Intent in = new Intent(this, MyAnimation.class);
        startActivity(in);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int idNivchar = item.getItemId();
        if (idNivchar == R.id.exit)
            exit();
        if (idNivchar == R.id.anim)
            showAnim();
        if (idNivchar == R.id.restart)
            restart();
        if (idNivchar == R.id.save)
            save();
        if (idNivchar == R.id.load)
            load();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        Button btn = (Button) v;
        String hint = btn.getHint().toString();
        int shura = (hint.charAt(0) - 48);
        int amuda = (hint.charAt(2) - 48);
        if (first_tap) {
            rowFrom = shura;
            colFrom = amuda;
            first_tap = false;
        } else {
            int turn_player = gameMgr.makeMove(rowFrom, colFrom, shura, amuda);
            first_tap = true;
            markCurrentPlayer(turn_player);
            gameMgr.isWinner();
        }
    }

    public void initButtons()
    {
        Log.d("initButtons()","in");
        for (int sh = 0; sh < Board.MisparShurot; sh++) {
            for (int am = 0; am < Board.MisparAmudot; am++) {
                char x = (char) ('0' + sh);
                char y = (char) ('0' + am);
                String str = "btn" + x + y;
                Log.d("initButtons()","str = "+str);
                int resId = getResources().getIdentifier(str, "id", getPackageName());
                caftor[sh][am] = findViewById(resId);
                caftor[sh][am].setHint(x + " " + y);
                caftor[sh][am].setText("");
                caftor[sh][am].setOnClickListener(this);
            }
        }
    }

    @Override
    public void drawBoard(Board board) {
        for (int i = 0; i < Board.MisparShurot; i++) {
            for (int k = 0; k < Board.MisparAmudot; k++) {
                int plNum = board.getValue(i, k);
                if (plNum == 2) {
                    caftor[i][k].setForeground(getDrawable(R.drawable.bajphoto));
                }
                if (plNum == 0) {
                    caftor[i][k].setForeground(getDrawable(R.drawable.black));
                }
                if (plNum == 3 ){
                    caftor[i][k].setForeground(getDrawable(R.drawable.checkerspng_5));
                }
                if (plNum == -3) {
                    caftor[i][k].setForeground(getDrawable(R.drawable.checkers_png17));
                }
                if (plNum == 1) {
                    caftor[i][k].setForeground(getDrawable(R.drawable.circlebrown));
                }
                if (plNum == -1) {
                    caftor[i][k].setForeground(getDrawable(R.drawable.whitecircle));
                }
            }
        }
    }


    @Override
    public void markCurrentPlayer(int playerNum) {
        btnTor = findViewById(R.id.btnTor);
        if (playerNum == 1) {
            btnTor.setText("the turn is of " + NameA);
        } else {
            btnTor.setText("the turn is of " + NameB);
        }
    }

    private void exit() {
        this.finish();
    }

    private void showAnim() {
        Toast.makeText(getApplicationContext(), "animation", Toast.LENGTH_LONG).show();
        Intent in = new Intent(this, MyAnimation.class);
        startActivity(in);
    }

    private void restart() {
        gameMgr.restart();
        if (!caftor[0][0].isClickable()) {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    caftor[i][j].setClickable(true);
                }
            }
        }
    }

    public void save() {
        // שמירת הלוח
        try {
            FileOutputStream fos = openFileOutput(Board.Filename, Context.MODE_PRIVATE);
            gameMgr.saveBoard(fos);
            fos.close();
        } catch (Exception e) {

        }
    }

    public void load() {
        // טעינת לוח
        try {
            FileInputStream fis = openFileInput(Board.Filename);
            gameMgr.loadBoard(fis);
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "cannot open board file", Toast.LENGTH_LONG).show();
        }

    }

    public void makeAnim() {
        Intent in = new Intent(this, MyAnimation.class);
        startActivity(in);
    }

}