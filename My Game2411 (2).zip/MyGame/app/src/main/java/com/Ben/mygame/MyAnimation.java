package com.Ben.mygame;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MyAnimation extends AppCompatActivity
{
    MyHandler myHn;
    MyThread myTh;

    ImageView ivChamor;
    private Drawable [] arrDmuyot;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_animation);

        ivChamor = (ImageView) findViewById(R.id.ivChamor);
        arrDmuyot = new Drawable[13];
        for(int i = 1; i < 13; i++)
        {
            String drawableName = "donkey_frm_" + i;
            int resID = getResources().getIdentifier(drawableName, "drawable", getPackageName());
            arrDmuyot[i] = getResources().getDrawable(resID);
        }
        myHn = new MyHandler(this);
        startAnim();
    }

    public void drawDmut(int num)
    {
        ivChamor.setImageDrawable(arrDmuyot[num]);
    }

    public void startAnim()
    {
        if(myTh == null)
        {
            myTh = new MyThread(myHn);
            // במקביל שיעבוד כך התהליכון את מפעיל
            myTh.start();
        }

    }


    public void stopAnim(View v)
    {
        myTh.setStop(true);
        finish();
    }
}