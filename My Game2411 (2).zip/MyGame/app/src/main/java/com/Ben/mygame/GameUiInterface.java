package com.Ben.mygame;

public interface GameUiInterface
{
    public void drawBoard(Board board);
    public void markCurrentPlayer(int playerNum);
    public void show_winner();
}
